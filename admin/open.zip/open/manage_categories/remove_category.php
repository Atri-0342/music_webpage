<?php
session_name("ADMIN_SESSION");
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: ../admin_login.php");
    exit;
}

require_once '../db.php';

if (!isset($_GET['id'])) {
    header("Location: categories.php");
    exit;
}

$id = (int)$_GET['id'];

// Optionally: remove image file from server
$stmt = $pdo->prepare("SELECT image FROM categories WHERE id=?");
$stmt->execute([$id]);
$category = $stmt->fetch();

if ($category && $category['image'] && file_exists("../uploads/".$category['image'])) {
    unlink("../uploads/".$category['image']);
}

// Delete category
$stmt = $pdo->prepare("DELETE FROM categories WHERE id=?");
$stmt->execute([$id]);

header("Location: categories.php");
exit;

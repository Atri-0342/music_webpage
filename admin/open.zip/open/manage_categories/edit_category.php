<?php
session_name("ADMIN_SESSION");
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: ../admin_login.php");
    exit;
}

require_once '../db.php';
$message = "";

// Fetch category
if (!isset($_GET['id'])) {
    header("Location: categories.php");
    exit;
}
$id = (int)$_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM categories WHERE id=?");
$stmt->execute([$id]);
$category = $stmt->fetch();
if (!$category) {
    header("Location: categories.php");
    exit;
}

// Handle edit
if (isset($_POST['edit_category'])) {
    $name = $_POST['name'];
    $image = $category['image'];

    if (!empty($_FILES['image']['name'])) {
        $targetDir = "../uploads/category/";
        if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);

        $fileName = time() . "_" . basename($_FILES["image"]["name"]);
        $targetFilePath = $targetDir . $fileName;

        if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath)) {
            // Remove old image if exists
            if ($category['image'] && file_exists("../uploads/".$category['image'])) {
                unlink("../uploads/".$category['image']);
            }
            $image = "category/" . $fileName; // save relative path
        } else {
            $message = "❌ Error uploading image!";
        }
    }

    $stmt = $pdo->prepare("UPDATE categories SET name=?, image=? WHERE id=?");
    if ($stmt->execute([$name, $image, $id])) {
        header("Location: categories.php");
        exit;
    } else {
        $message = "❌ Error updating category.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Category</title>
<style>
body { font-family: Arial, sans-serif; background: #f4f6f9; padding:20px; }
.container { max-width:500px; margin:auto; background:#fff; padding:20px; border-radius:10px; box-shadow:0 2px 6px rgba(0,0,0,0.1); }
h2 { text-align:center; color:#243b55; }
.form-group { margin-bottom:15px; }
label { display:block; font-weight:bold; margin-bottom:5px; }
input[type="text"], input[type="file"] { width:100%; padding:10px; border:1px solid #ccc; border-radius:6px; }
button { width:100%; padding:12px; border:none; border-radius:6px; background:#243b55; color:#fff; cursor:pointer; font-size:16px; }
button:hover { background:#00cc7a; }
.msg { text-align:center; margin-top:10px; font-weight:bold; color:red; }
.back { display:block; margin-top:15px; text-align:center; text-decoration:none; background:#ccc; color:#000; padding:10px; border-radius:6px; }
.current-img { display:block; margin-bottom:10px; width:80px; height:80px; object-fit:cover; border-radius:6px; }
</style>
</head>
<body>

<div class="container">
<h2>✏️ Edit Category</h2>

<?php if($message): ?>
<div class="msg"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<form method="POST" enctype="multipart/form-data">
    <div class="form-group">
        <label>Category Name</label>
        <input type="text" name="name" value="<?= htmlspecialchars($category['name']) ?>" required>
    </div>
    <div class="form-group">
        <label>Current Image</label>
        <?php if($category['image'] && file_exists("../uploads/".$category['image'])): ?>
            <img src="../uploads/<?= htmlspecialchars($category['image']) ?>" class="current-img" alt="Category">
        <?php else: ?>
            <span>None</span>
        <?php endif; ?>
    </div>
    <div class="form-group">
        <label>Change Image</label>
        <input type="file" name="image" accept="image/*">
    </div>
    <button type="submit" name="edit_category">Update Category</button>
</form>

<a href="categories.php" class="back">← Back to Categories</a>
</div>
</body>
</html>

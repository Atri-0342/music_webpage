<?php
session_name("ADMIN_SESSION");
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: ../admin_login.php");
    exit;
}

require_once '../db.php';
$message = "";

if (isset($_POST['add_category'])) {
    $name = $_POST['name'];

    // Handle image upload
    $image = null;
    if (!empty($_FILES['image']['name'])) {
        $targetDir = "../uploads/category/";
        if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);

        $fileName = time() . "_" . basename($_FILES["image"]["name"]);
        $targetFilePath = $targetDir . $fileName;

        if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath)) {
            $image = "category/" . $fileName; // save relative path
        } else {
            $message = "❌ Error uploading image!";
        }
    }

    // Insert into DB
    $stmt = $pdo->prepare("INSERT INTO categories (name, image) VALUES (?, ?)");
    if ($stmt->execute([$name, $image])) {
        $message = "✅ Category added successfully!";
    } else {
        $message = "❌ Error adding category.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Category</title>
<style>
body { font-family: Arial, sans-serif; background: #f4f6f9; padding: 20px; }
.container { max-width: 500px; margin:auto; background:#fff; padding:20px; border-radius:10px; box-shadow:0 2px 6px rgba(0,0,0,0.1); }
h2 { text-align:center; color:#243b55; }
.form-group { margin-bottom:15px; }
label { display:block; font-weight:bold; margin-bottom:5px; }
input[type="text"], input[type="file"] { width:100%; padding:10px; border:1px solid #ccc; border-radius:6px; }
button { width:100%; padding:12px; border:none; border-radius:6px; background:#243b55; color:#fff; cursor:pointer; font-size:16px; }
button:hover { background:#00cc7a; }
.msg { text-align:center; margin-top:10px; font-weight:bold; color:red; }
.back { display:block; margin-top:15px; text-align:center; text-decoration:none; background:#ccc; color:#000; padding:10px; border-radius:6px; }
</style>
</head>
<body>

<div class="container">
<h2>➕ Add New Category</h2>

<form method="POST" enctype="multipart/form-data">
    <div class="form-group">
        <label>Category Name</label>
        <input type="text" name="name" required>
    </div>
    <div class="form-group">
        <label>Image (optional)</label>
        <input type="file" name="image" accept="image/*">
    </div>
    <button type="submit" name="add_category">Add Category</button>
</form>

<?php if($message): ?>
<div class="msg"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<a href="categories.php" class="back">← Back to Categories</a>
</div>
</body>
</html>

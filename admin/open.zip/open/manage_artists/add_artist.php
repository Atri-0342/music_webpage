<?php
session_name("ADMIN_SESSION");
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: ../admin_login.php");
    exit;
}

require_once '../db.php'; // PDO connection
$message = "";

// Handle Add Artist form submission
if (isset($_POST['add_artist'])) {
    $artist_name = $_POST['username'];
    $email = $_POST['email'];
    $bio = $_POST['bio'] ?? null;
    $genre = $_POST['genre'] ?? null;

    // Handle profile picture upload
    $profile_pic = 'default_artist.png';
    if (!empty($_FILES['profile_pic']['name'])) {
        $targetDir = "../uploads/artists/";
        if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);

        $fileName = time() . "_" . basename($_FILES["profile_pic"]["name"]);
        $targetFilePath = $targetDir . $fileName;

        if (move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $targetFilePath)) {
            $profile_pic = "uploads/artists/" . $fileName;
        } else {
            $message = "❌ Error uploading profile picture. Default will be used.";
        }
    }

    $stmt = $pdo->prepare("INSERT INTO artists (username, email, bio, genre, profile_pic) VALUES (?, ?, ?, ?, ?)");
    if ($stmt->execute([$artist_name, $email, $bio, $genre, $profile_pic])) {
        $message = "✅ Artist added successfully!";
    } else {
        $message = "❌ Error adding artist.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Artist</title>
<style>
body { font-family: Arial, sans-serif; background: #f4f6f9; margin: 0; padding: 20px; }
.container { max-width: 600px; margin: auto; background: #fff; padding: 30px; border-radius: 10px; box-shadow: 0 2px 6px rgba(0,0,0,0.1); }
h2 { color: #243b55; text-align: center; margin-bottom: 20px; }
.form-group { margin-bottom: 15px; }
label { font-weight: bold; display: block; margin-bottom: 5px; }
input[type="text"], input[type="email"], textarea, input[type="file"] { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 6px; }
textarea { resize: vertical; min-height: 80px; }
button { background: #243b55; color: #fff; padding: 12px; border: none; border-radius: 6px; cursor: pointer; width: 100%; font-size: 16px; }
button:hover { background: #00cc7a; }
.msg { margin-top: 15px; text-align: center; font-weight: bold; }
a.back { display: inline-block; margin-top: 15px; text-decoration: none; padding: 10px 16px; background: #ccc; color: #000; border-radius: 6px; }
</style>
</head>
<body>

<div class="container">
<h2>➕ Add New Artist</h2>
<form method="POST" enctype="multipart/form-data">
    <div class="form-group">
        <label>Username</label>
        <input type="text" name="username" required>
    </div>
    <div class="form-group">
        <label>Email</label>
        <input type="email" name="email" required>
    </div>
    <div class="form-group">
        <label>Bio</label>
        <textarea name="bio" placeholder="Artist bio"></textarea>
    </div>
    <div class="form-group">
        <label>Genre</label>
        <input type="text" name="genre" placeholder="Artist genre">
    </div>
    <div class="form-group">
        <label>Profile Picture (optional)</label>
        <input type="file" name="profile_pic" accept="image/*">
    </div>
    <button type="submit" name="add_artist">Add Artist</button>
</form>

<?php if ($message): ?>
<div class="msg"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<a href="artists.php" class="back">← Back to Artists</a>
</div>

</body>
</html>

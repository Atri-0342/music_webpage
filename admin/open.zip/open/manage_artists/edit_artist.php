<?php
session_name("ADMIN_SESSION");
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: ../admin_login.php");
    exit;
}

$username = $_SESSION['admin_username'];
require_once '../db.php'; // PDO connection

// Fetch artist to edit
if (!isset($_GET['id'])) {
    header("Location: artists.php");
    exit;
}
$id = $_GET['id'];

$stmt = $pdo->prepare("SELECT * FROM artists WHERE id=?");
$stmt->execute([$id]);
$artist = $stmt->fetch();
if (!$artist) {
    header("Location: artists.php");
    exit;
}

$message = "";

// Handle Edit Artist form submission
if (isset($_POST['edit_artist'])) {
    $artist_name = $_POST['username'];
    $email = $_POST['email'];
    $bio = $_POST['bio'] ?? null;
    $genre = $_POST['genre'] ?? null;

    // Handle profile picture upload
    $profile_pic = $artist['profile_pic']; // current pic
    if (!empty($_FILES['profile_pic']['name'])) {
        $targetDir = "../uploads/artists/";
        if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);

        $fileName = time() . "_" . basename($_FILES["profile_pic"]["name"]);
        $targetFilePath = $targetDir . $fileName;

        if (move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $targetFilePath)) {
            $profile_pic = "uploads/artists/" . $fileName; // store relative path in DB
        } else {
            $message = "❌ Error uploading profile picture!";
        }
    }

    // Update DB
    $stmt = $pdo->prepare("UPDATE artists SET username=?, email=?, bio=?, genre=?, profile_pic=? WHERE id=?");
    $stmt->execute([$artist_name, $email, $bio, $genre, $profile_pic, $id]);

    if (!$message) {
        header("Location: artists.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Artist</title>
<style>
body { font-family: Arial, sans-serif; background: #f4f6f9; padding: 20px; }
.container { max-width: 600px; margin: auto; background: #fff; padding: 20px; border-radius: 10px; box-shadow: 0 2px 6px rgba(0,0,0,0.1); }
h2 { color: #243b55; text-align: center; margin-bottom: 20px; }
.form-group { margin-bottom: 15px; }
label { font-weight: bold; display:block; margin-bottom:5px; }
input[type="text"], input[type="email"], textarea, input[type="file"] { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 6px; }
textarea { resize: vertical; min-height: 80px; }
button { background: #243b55; color: #fff; padding: 12px; border: none; border-radius: 6px; cursor: pointer; width: 100%; font-size: 16px; }
button:hover { background: #00cc7a; }
.back { display:block; margin-top:10px; text-align:center; text-decoration:none; color:#000; background:#ccc; padding:10px 0; border-radius:6px; }
.msg { margin-top: 10px; font-weight: bold; color: red; text-align:center; }
.current-pic { display:block; margin-bottom:10px; width:80px; height:80px; border-radius:50%; object-fit:cover; }
</style>
</head>
<body>

<div class="container">
<h2>✏️ Edit Artist</h2>

<?php if($message): ?>
<div class="msg"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<form method="POST" enctype="multipart/form-data">
    <div class="form-group">
        <label>Username</label>
        <input type="text" name="username" value="<?= htmlspecialchars($artist['username']) ?>" required>
    </div>
    <div class="form-group">
        <label>Email</label>
        <input type="email" name="email" value="<?= htmlspecialchars($artist['email']) ?>" required>
    </div>
    <div class="form-group">
        <label>Bio</label>
        <textarea name="bio"><?= htmlspecialchars($artist['bio']) ?></textarea>
    </div>
    <div class="form-group">
        <label>Genre</label>
        <input type="text" name="genre" value="<?= htmlspecialchars($artist['genre']) ?>">
    </div>
    <div class="form-group">
        <label>Profile Picture</label>
        <?php if($artist['profile_pic'] && file_exists("../" . $artist['profile_pic'])): ?>
            <img src="../<?= htmlspecialchars($artist['profile_pic']) ?>" class="current-pic" alt="Profile">
        <?php else: ?>
            <span>None</span>
        <?php endif; ?>
        <input type="file" name="profile_pic" accept="image/*">
    </div>
    <button type="submit" name="edit_artist">Update Artist</button>
</form>

<a href="artists.php" class="back">Cancel</a>
</div>

</body>
</html>

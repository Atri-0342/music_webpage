<?php
session_name("ADMIN_SESSION");
session_start();

// Redirect if not logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../admin_login.php");
    exit;
}

require_once '../db.php'; // PDO connection

// Check if ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: artists.php");
    exit;
}

$id = $_GET['id'];

// Delete the artist
$stmt = $pdo->prepare("DELETE FROM artists WHERE id = ?");
$stmt->execute([$id]);

// Redirect back to the artists page
header("Location: artists.php");
exit;
?>

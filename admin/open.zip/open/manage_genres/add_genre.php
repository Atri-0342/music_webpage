<?php
session_name("ADMIN_SESSION");
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: ../admin_login.php");
    exit;
}

$username = $_SESSION['admin_username'];
require_once '../db.php';

$message = "";

// Handle form submission
if (isset($_POST['add_genre'])) {
    $name = $_POST['name'];

    // Handle image upload
    $image = null;
    if (!empty($_FILES['image']['name'])) {
        $targetDir = "../uploads/genre/";
        if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);

        $fileName = time() . "_" . basename($_FILES['image']['name']);
        $targetFile = $targetDir . $fileName;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
            $image = "genre/" . $fileName;
        } else {
            $message = "❌ Error uploading image.";
        }
    }

    // Insert into DB
    $stmt = $pdo->prepare("INSERT INTO genres (name, image) VALUES (?, ?)");
    if ($stmt->execute([$name, $image])) {
        header("Location: genres.php");
        exit;
    } else {
        $message = "❌ Error adding genre.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Genre</title>
<style>
body { font-family: Arial, sans-serif; background: #f4f6f9; padding: 20px; }
.container { max-width: 500px; margin:auto; background:#fff; padding:30px; border-radius:10px; box-shadow:0 2px 6px rgba(0,0,0,0.1); }
h2 { text-align:center; color:#243b55; }
input[type="text"], input[type="file"] { width:100%; padding:10px; margin-bottom:15px; border-radius:6px; border:1px solid #ccc; }
button { background:#243b55; color:#fff; width:100%; padding:12px; border:none; border-radius:6px; cursor:pointer; font-size:16px; }
button:hover { background:#00cc7a; }
.back { display:block; margin-top:15px; text-align:center; text-decoration:none; background:#ccc; padding:10px 0; border-radius:6px; color:#000; }
.msg { text-align:center; font-weight:bold; color:red; margin-bottom:10px; }
</style>
</head>
<body>

<div class="container">
<h2>➕ Add New Genre</h2>

<?php if($message): ?>
<div class="msg"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<form method="POST" enctype="multipart/form-data">
    <input type="text" name="name" placeholder="Genre Name" required>
    <input type="file" name="image" accept="image/*">
    <button type="submit" name="add_genre">Add Genre</button>
</form>

<a href="genres.php" class="back">← Back to Genres</a>
</div>

</body>
</html>

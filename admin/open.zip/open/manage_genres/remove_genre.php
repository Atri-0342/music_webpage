<?php
session_name("ADMIN_SESSION");
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: ../admin_login.php");
    exit;
}

require_once '../db.php';

if (!isset($_GET['id'])) {
    header("Location: genres.php");
    exit;
}

$id = (int)$_GET['id'];

// Optional: delete image file from server
$stmt = $pdo->prepare("SELECT image FROM genres WHERE id=?");
$stmt->execute([$id]);
$genre = $stmt->fetch();
if ($genre && $genre['image'] && file_exists("../uploads/".$genre['image'])) {
    unlink("../uploads/".$genre['image']);
}

// Delete genre
$stmt = $pdo->prepare("DELETE FROM genres WHERE id=?");
$stmt->execute([$id]);

header("Location: genres.php");
exit;

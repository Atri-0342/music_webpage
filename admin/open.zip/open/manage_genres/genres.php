<?php
session_name("ADMIN_SESSION");
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: ../admin_login.php");
    exit;
}

$username = $_SESSION['admin_username'];
require_once '../db.php';

// Handle delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM genres WHERE id=?");
    $stmt->execute([$id]);
    header("Location: genres.php");
    exit;
}

// Search
$search = $_GET['search'] ?? '';

// Pagination
$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Total rows
if ($search != '') {
    $stmt = $pdo->prepare("SELECT COUNT(*) AS total FROM genres WHERE name LIKE ?");
    $stmt->execute(["%$search%"]);
} else {
    $stmt = $pdo->query("SELECT COUNT(*) AS total FROM genres");
}
$total_row = $stmt->fetch(PDO::FETCH_ASSOC);
$total_pages = ceil($total_row['total'] / $limit);

// Fetch genres
if ($search != '') {
    $stmt = $pdo->prepare("SELECT * FROM genres WHERE name LIKE ? ORDER BY id DESC");
    $stmt->execute(["%$search%"]);
} else {
    $stmt = $pdo->prepare("SELECT * FROM genres ORDER BY id DESC LIMIT ? OFFSET ?");
    $stmt->bindValue(1, $limit, PDO::PARAM_INT);
    $stmt->bindValue(2, $offset, PDO::PARAM_INT);
    $stmt->execute();
}
$genres = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Genres</title>
<style>
body { font-family: "Segoe UI", sans-serif; margin:0; background:#f4f6f9; }
header { background:#243b55; color:#fff; padding:20px; text-align:center; }
header h1 { margin:0; font-size:24px; }
header p { margin-top:5px; }
.container { display:flex; }
nav { width:250px; background:#141e30; min-height:100vh; padding-top:20px; color:#fff; box-sizing:border-box; }
nav a { display:block; padding:12px 20px; color:#fff; text-decoration:none; font-size:16px; }
nav a:hover { background:#00cc7a; }
main { flex:1; padding:30px; }
.card { background:#fff; padding:20px; margin-bottom:20px; border-radius:10px; box-shadow:0 2px 6px rgba(0,0,0,0.1); position: relative; }
.card h2 { margin-top:0; }
table { width:100%; border-collapse:collapse; margin-top:10px; }
table th, table td { padding:10px; border:1px solid #ccc; text-align:left; }
table th { background:#141e30; color:#fff; }
.actions a { margin-right:5px; text-decoration:none; color:#fff; padding:6px 10px; border-radius:4px; display:inline-block; }
.actions a.edit { background:#00cc7a; }
.actions a.delete { background:#ff4d4d; }
.actions a.edit:hover { background:#00995c; }
.actions a.delete:hover { background:#e60000; }
form input[type="text"] { padding:6px; margin-right:5px; }
form input[type="submit"], .add-btn { background:#00cc7a; color:#fff; border:none; border-radius:4px; cursor:pointer; padding:6px 12px; text-decoration:none; }
form input[type="submit"]:hover, .add-btn:hover { background:#00995c; }
.pagination a { margin:0 5px; text-decoration:none; padding:6px 12px; background:#141e30; color:#fff; border-radius:4px; }
.pagination a.active { background:#00cc7a; }
.logout-btn { display:inline-block; margin-top:10px; padding:10px 20px; background:#ff4d4d; color:#fff; border:none; border-radius:6px; cursor:pointer; text-decoration:none; }
.logout-btn:hover { background:#e60000; }
.genre-img { width:60px; height:60px; object-fit:cover; border-radius:6px; }
</style>
</head>
<body>

<header>
<h1>🎶 Manage Genres</h1>
<p>Welcome, <b><?= htmlspecialchars($username) ?></b></p>
<a href="../logout_admin.php" class="logout-btn">Logout</a>
</header>

<div class="container">
<nav>
<a href="../index.php">🏠 Dashboard</a>
<a href="../manage_songs/songs.php">🎵 Songs</a>
<a href="../manage_artists/artists.php">🎤 Artists</a>
<a href="../manage_genres/genres.php">🎶 Genres</a>
<a href="../manage_categories/categories.php">📁 Categories</a>
<a href="../manage_users/users.php">👥 Users</a>
</nav>

<main>
<div class="card">
<h2>All Genres</h2>
<div style="margin-bottom:10px;">
<a href="add_genre.php" class="add-btn">➕ Add New Genre</a>
</div>
<br><br>
<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
    <form method="GET" action="" style="margin:0;">
        <input type="text" name="search" placeholder="Search by title" value="<?= htmlspecialchars($search) ?>">
        <input type="submit" value="Search">
    </form>

    <?php if($search == ''): ?>
    <div class="pagination" style="margin:0;">
        <?php for($i=1; $i<=$total_pages; $i++): ?>
        <a href="?page=<?= $i ?>" class="<?= ($i==$page)?'active':'' ?>"><?= $i ?></a>
        <?php endfor; ?>
    </div>
    <?php endif; ?>
</div>

<table>
<tr>
<th>ID</th>
<th>Name</th>
<th>Image</th>
<th>Created At</th>
<th>Actions</th>
</tr>

<?php foreach($genres as $g): ?>
<tr>
<td><?= $g['id'] ?></td>
<td><?= htmlspecialchars($g['name']) ?></td>
<td>
<?php if($g['image'] && file_exists("../uploads/".$g['image'])): ?>
<img src="../uploads/<?= htmlspecialchars($g['image']) ?>" class="genre-img" alt="Genre">
<?php else: ?>
None
<?php endif; ?>
</td>
<td><?= $g['created_at'] ?></td>
<td class="actions">
<a class="edit" href="edit_genre.php?id=<?= $g['id'] ?>">Edit</a>
<a class="delete" href="remove_genre.php?id=<?= $g['id'] ?>" onclick="return confirm('Are you sure you want to delete this genre?');">Delete</a>
</td>
</tr>
<?php endforeach; ?>
</table>
</div>
</main>
</div>
</body>
</html>

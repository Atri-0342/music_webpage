<?php
session_name("ADMIN_SESSION");
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: ../admin_login.php");
    exit;
}

require_once '../db.php';

if (!isset($_GET['id'])) {
    header("Location: genres.php");
    exit;
}

$id = (int)$_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM genres WHERE id=?");
$stmt->execute([$id]);
$genre = $stmt->fetch();

if (!$genre) {
    header("Location: genres.php");
    exit;
}

$message = "";

if (isset($_POST['edit_genre'])) {
    $name = $_POST['name'];
    $image = $genre['image'];

    if (!empty($_FILES['image']['name'])) {
        $targetDir = "../uploads/genre/";
        if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);

        $fileName = time() . "_" . basename($_FILES['image']['name']);
        $targetFile = $targetDir . $fileName;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
            $image = "genre/" . $fileName;
        } else {
            $message = "❌ Error uploading image!";
        }
    }

    $stmt = $pdo->prepare("UPDATE genres SET name=?, image=? WHERE id=?");
    if ($stmt->execute([$name, $image, $id]) && !$message) {
        header("Location: genres.php");
        exit;
    } else {
        $message = $message ?: "❌ Error updating genre.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Genre</title>
<style>
body { font-family: Arial, sans-serif; background:#f4f6f9; padding:20px; }
.container { max-width:500px; margin:auto; background:#fff; padding:30px; border-radius:10px; box-shadow:0 2px 6px rgba(0,0,0,0.1); }
h2 { text-align:center; color:#243b55; }
input[type="text"], input[type="file"] { width:100%; padding:10px; margin-bottom:15px; border-radius:6px; border:1px solid #ccc; }
button { background:#243b55; color:#fff; width:100%; padding:12px; border:none; border-radius:6px; cursor:pointer; font-size:16px; }
button:hover { background:#00cc7a; }
.back { display:block; margin-top:15px; text-align:center; text-decoration:none; background:#ccc; padding:10px 0; border-radius:6px; color:#000; }
.msg { text-align:center; font-weight:bold; color:red; margin-bottom:10px; }
.current-img { display:block; margin-bottom:10px; width:80px; height:80px; object-fit:cover; border-radius:6px; }
</style>
</head>
<body>

<div class="container">
<h2>✏️ Edit Genre</h2>

<?php if($message): ?>
<div class="msg"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<form method="POST" enctype="multipart/form-data">
    <input type="text" name="name" value="<?= htmlspecialchars($genre['name']) ?>" required>

    <?php if($genre['image'] && file_exists("../uploads/".$genre['image'])): ?>
        <img src="../uploads/<?= htmlspecialchars($genre['image']) ?>" class="current-img" alt="Genre">
    <?php else: ?>
        <span>No image</span>
    <?php endif; ?>

    <input type="file" name="image" accept="image/*">
    <button type="submit" name="edit_genre">Update Genre</button>
</form>

<a href="genres.php" class="back">← Back to Genres</a>
</div>
</body>
</html>

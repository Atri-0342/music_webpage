<?php
session_name("ADMIN_SESSION");
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: ../admin_login.php");
    exit;
}

$username = $_SESSION['admin_username'];
require_once '../db.php';

// Handle delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM users WHERE id=?");
    $stmt->execute([$id]);
    header("Location: users.php");
    exit;
}

// Search
$search = $_GET['search'] ?? '';

// Pagination setup
$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Total users
if ($search != '') {
    $stmt = $pdo->prepare("SELECT COUNT(*) AS total FROM users WHERE name LIKE ? OR mail LIKE ?");
    $stmt->execute(["%$search%", "%$search%"]);
} else {
    $stmt = $pdo->query("SELECT COUNT(*) AS total FROM users");
}
$total_row = $stmt->fetch(PDO::FETCH_ASSOC);
$total_pages = ceil($total_row['total'] / $limit);

// Fetch users
if ($search != '') {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE name LIKE ? OR mail LIKE ? ORDER BY id DESC");
    $stmt->execute(["%$search%", "%$search%"]);
} else {
    $stmt = $pdo->prepare("SELECT * FROM users ORDER BY id DESC LIMIT ? OFFSET ?");
    $stmt->bindValue(1, $limit, PDO::PARAM_INT);
    $stmt->bindValue(2, $offset, PDO::PARAM_INT);
    $stmt->execute();
}
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Users</title>
<style>
body { font-family:"Segoe UI",sans-serif; margin:0; background:#f4f6f9; }
header { background:#243b55; color:#fff; padding:20px; text-align:center; }
header h1 { margin:0; font-size:24px; }
header p { margin-top:5px; }
.container { display:flex; }
nav { width:250px; background:#141e30; min-height:100vh; padding-top:20px; color:#fff; box-sizing:border-box; }
nav a { display:block; padding:12px 20px; color:#fff; text-decoration:none; font-size:16px; }
nav a:hover { background:#00cc7a; }
main { flex:1; padding:30px; }
.card { background:#fff; padding:20px; margin-bottom:20px; border-radius:10px; box-shadow:0 2px 6px rgba(0,0,0,0.1); position:relative; }
.card h2 { margin-top:0; }
table { width:100%; border-collapse:collapse; margin-top:10px; }
table th, table td { padding:10px; border:1px solid #ccc; text-align:left; vertical-align:middle; }
table th { background:#141e30; color:#fff; }
.actions a { margin-right:5px; text-decoration:none; color:#fff; padding:6px 10px; border-radius:4px; display:inline-block; }
.actions a.delete { background:#ff4d4d; }
.actions a.delete:hover { background:#e60000; }
form input[type="text"] { padding:6px; margin-right:5px; width:200px; }
form input[type="submit"] { background:#00cc7a; color:#fff; border:none; border-radius:4px; cursor:pointer; padding:6px 12px; }
form input[type="submit"]:hover { background:#00995c; }
.pagination a { margin:0 3px; text-decoration:none; padding:6px 12px; background:#141e30; color:#fff; border-radius:4px; }
.pagination a.active { background:#00cc7a; }
.logout-btn { display:inline-block; margin-top:10px; padding:10px 20px; background:#ff4d4d; color:#fff; border:none; border-radius:6px; cursor:pointer; text-decoration:none; }
.logout-btn:hover { background:#e60000; }
.top-bar { display:flex; justify-content:space-between; align-items:center; margin-bottom:15px; flex-wrap:wrap; }
.search-box { display:flex; align-items:center; gap:5px; }
</style>
</head>
<body>

<header>
<h1>👥 Manage Users</h1>
<p>Welcome, <b><?= htmlspecialchars($username) ?></b></p>
<a href="../logout_admin.php" class="logout-btn">Logout</a>
</header>

<div class="container">
<nav>
<a href="../index.php">🏠 Dashboard</a>
<a href="../manage_songs/songs.php">🎵 Songs</a>
<a href="../manage_artists/artists.php">🎤 Artists</a>
<a href="../manage_genres/genres.php">🎶 Genres</a>
<a href="../manage_categories/categories.php">📁 Categories</a>
<a href="../manage_users/users.php">👥 Users</a>
</nav>

<main>
<div class="card">
<h2>All Users</h2>

<div class="top-bar">
    <form method="GET" action="" class="search-box">
        <input type="text" name="search" placeholder="Search by name or email" value="<?= htmlspecialchars($search) ?>">
        <input type="submit" value="Search">
    </form>

    <?php if($search == ''): ?>
    <div class="pagination">
        <?php for($i=1; $i<=$total_pages; $i++): ?>
        <a href="?page=<?= $i ?>" class="<?= ($i==$page)?'active':'' ?>"><?= $i ?></a>
        <?php endfor; ?>
    </div>
    <?php endif; ?>
</div>

<table>
<tr>
<th>ID</th>
<th>Name</th>
<th>Email</th>
<th>DOB</th>
<th>City</th>
<th>Phone</th>
<th>Actions</th>
</tr>

<?php foreach($users as $u): ?>
<tr>
<td><?= $u['id'] ?></td>
<td><?= htmlspecialchars($u['name']) ?></td>
<td><?= htmlspecialchars($u['mail']) ?></td>
<td><?= htmlspecialchars($u['dob']) ?></td>
<td><?= htmlspecialchars($u['city'] ?? '-') ?></td>
<td><?= htmlspecialchars($u['phone'] ?? '-') ?></td>
<td class="actions">
<a class="delete" href="users.php?delete=<?= $u['id'] ?>" onclick="return confirm('Are you sure you want to delete this user?');">Delete</a>
</td>
</tr>
<?php endforeach; ?>
</table>

</div>
</main>
</div>
</body>
</html>

<?php
require '../db.php';
session_name("ADMIN_SESSION");
session_start();

// Check admin login
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../admin_login.php");
    exit;
}

$message = "";

// Fetch artists, categories, genres for dropdowns
$artists = $pdo->query("SELECT id, username FROM artists ORDER BY username ASC")->fetchAll(PDO::FETCH_ASSOC);
$categories = $pdo->query("SELECT id, name FROM categories ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
$genres = $pdo->query("SELECT id, name FROM genres ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $artist_id = $_POST['artist_id'];
    $category_id = $_POST['category_id'] ?: null;
    $genre_id = $_POST['genre_id'] ?: null;
    $album = $_POST['album'];
    $duration = $_POST['duration'];
    $uploaded_by = $_SESSION['admin_id'];
    $status = 'approved';

    // File upload folder
    $uploadDir = "../uploads/songs/";
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

    // Upload audio
    $audioFileName = time() . "_" . basename($_FILES['file']['name']);
    $audioFilePath = $uploadDir . $audioFileName;

    if (!move_uploaded_file($_FILES['file']['tmp_name'], $audioFilePath)) {
        $message = "❌ Error uploading audio file!";
    }

    // Optional cover image
    $coverFileName = null;
    if (!empty($_FILES['cover']['name'])) {
        $coverFileName = time() . "_cover_" . basename($_FILES['cover']['name']);
        $coverFilePath = $uploadDir . $coverFileName;
        if (!move_uploaded_file($_FILES['cover']['tmp_name'], $coverFilePath)) {
            $message = "❌ Error uploading cover image!";
        }
    }

    if (!$message) {
        $stmt = $pdo->prepare("
            INSERT INTO songs (title, artist_id, album, category_id, genre_id, duration, file_path, cover_image, status, uploaded_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$title, $artist_id, $album, $category_id, $genre_id, $duration, $audioFileName, $coverFileName, $status, $uploaded_by]);
        $message = "✅ Song uploaded successfully! Duration: $duration";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Song</title>

<!-- Select2 CSS -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

<style>
body { font-family: Arial, sans-serif; background:#f4f6f9; padding:20px; }
.container { max-width:600px; margin:auto; background:#fff; padding:20px; border-radius:10px; box-shadow:0 2px 6px rgba(0,0,0,0.1); }
h2 { color:#243b55; text-align:center; }
.form-group { margin-bottom:15px; }
label { font-weight:bold; display:block; margin-bottom:5px; }
input[type="text"], select, input[type="file"] { width:100%; padding:10px; border:1px solid #ccc; border-radius:6px; }
button { background:#243b55; color:#fff; padding:12px; border:none; border-radius:6px; cursor:pointer; width:100%; font-size:16px; }
button:hover { background:#00cc7a; }
.back-btn {
  background:#ccc;
  color:#000;
  margin-top:10px;
}
.back-btn:hover {
  background:#999;
  color:#fff;
}
.msg { margin-top:15px; text-align:center; font-weight:bold; }

/* ✅ Fix text cutoff in Select2 boxes */
.select2-container { width: 100% !important; }
.select2-container .select2-selection--single .select2-selection__rendered {
  white-space: nowrap !important;
  overflow: visible !important;
  text-overflow: unset !important;
  width: 100% !important;
}
</style>
</head>
<body>
<div class="container">
<h2>➕ Add New Song</h2>

<form method="POST" enctype="multipart/form-data">
    <div class="form-group">
        <label>Title</label>
        <input type="text" name="title" required>
    </div>

    <div class="form-group">
        <label>Artist</label>
        <select name="artist_id" class="select2" required>
            <option value="">Select Artist</option>
            <?php foreach($artists as $a): ?>
                <option value="<?= $a['id'] ?>"><?= htmlspecialchars($a['username']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="form-group">
        <label>Category</label>
        <select name="category_id" class="select2">
            <option value="">None</option>
            <?php foreach($categories as $c): ?>
                <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="form-group">
        <label>Genre</label>
        <select name="genre_id" class="select2">
            <option value="">None</option>
            <?php foreach($genres as $g): ?>
                <option value="<?= $g['id'] ?>"><?= htmlspecialchars($g['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="form-group">
        <label>Album</label>
        <input type="text" name="album">
    </div>

    <div class="form-group">
        <label>Duration (auto-filled)</label>
        <input type="text" name="duration" id="duration" readonly>
    </div>

    <div class="form-group">
        <label>Upload Audio File</label>
        <input type="file" name="file" id="file" accept="audio/*" required>
    </div>

    <div class="form-group">
        <label>Cover Image (optional)</label>
        <input type="file" name="cover" accept="image/*">
    </div>

    <button type="submit">Upload Song</button>
    <button type="button" class="back-btn" onclick="window.location.href='songs.php'">⬅ Back</button>
</form>

<?php if($message): ?>
<div class="msg"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>
</div>

<!-- jQuery (required by Select2) -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Select2 JS -->
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
$(document).ready(function() {
    $('.select2').select2({
        placeholder: "Select an option",
        allowClear: true,
        width: '100%'
    });

    // Auto-calculate duration
    $('#file').on('change', function() {
        const file = this.files[0];
        if (file) {
            const audio = document.createElement('audio');
            audio.preload = 'metadata';
            audio.onloadedmetadata = function() {
                window.URL.revokeObjectURL(audio.src);
                const duration = audio.duration;
                const minutes = Math.floor(duration / 60);
                const seconds = Math.floor(duration % 60);
                $('#duration').val(`${minutes}:${seconds < 10 ? '0'+seconds : seconds}`);
            };
            audio.src = URL.createObjectURL(file);
        }
    });
});
</script>

</body>
</html>

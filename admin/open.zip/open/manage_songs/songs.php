<?php
session_name("ADMIN_SESSION");
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: ../admin_login.php");
    exit;
}

$username = $_SESSION['admin_username'];
require_once '../db.php'; // PDO connection


// Search term
$search = $_GET['search'] ?? '';

// Pagination
$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Total rows
if ($search != '') {
    $stmt = $pdo->prepare("SELECT COUNT(*) AS total FROM songs WHERE title LIKE ?");
    $stmt->execute(["%$search%"]);
} else {
    $stmt = $pdo->query("SELECT COUNT(*) AS total FROM songs");
}
$total_row = $stmt->fetch(PDO::FETCH_ASSOC);
$total_pages = ceil($total_row['total'] / $limit);

// Fetch songs with JOIN to get artist, category, genre names
if ($search != '') {
    $stmt = $pdo->prepare("
        SELECT s.*, a.username AS artist_name, c.name AS category_name, g.name AS genre_name
        FROM songs s
        LEFT JOIN artists a ON s.artist_id = a.id
        LEFT JOIN categories c ON s.category_id = c.id
        LEFT JOIN genres g ON s.genre_id = g.id
        WHERE s.title LIKE ?
        ORDER BY s.id DESC
    ");
    $stmt->execute(["%$search%"]);
} else {
    $stmt = $pdo->prepare("
        SELECT s.*, a.username AS artist_name, c.name AS category_name, g.name AS genre_name
        FROM songs s
        LEFT JOIN artists a ON s.artist_id = a.id
        LEFT JOIN categories c ON s.category_id = c.id
        LEFT JOIN genres g ON s.genre_id = g.id
        ORDER BY s.id DESC
        LIMIT ? OFFSET ?
    ");
    $stmt->bindValue(1, $limit, PDO::PARAM_INT);
    $stmt->bindValue(2, $offset, PDO::PARAM_INT);
    $stmt->execute();
}
$songs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Songs</title>
<style>
body { font-family:"Segoe UI",sans-serif; margin:0; background:#f4f6f9; }
header { background:#243b55; color:#fff; padding:20px; text-align:center; }
header h1 { margin:0; font-size:24px; }
header p { margin-top:5px; }
.container { display:flex; }
nav { width:250px; background:#141e30; min-height:100vh; padding-top:20px; color:#fff; box-sizing:border-box; }
nav a { display:block; padding:12px 20px; color:#fff; text-decoration:none; font-size:16px; }
nav a:hover { background:#00cc7a; }
main { flex:1; padding:30px; }
.card { background:#fff; padding:20px; margin-bottom:20px; border-radius:10px; box-shadow:0 2px 6px rgba(0,0,0,0.1); }
.card h2 { margin-top:0; }
table { width:100%; border-collapse:collapse; margin-top:10px; }
table th, table td { padding:10px; border:1px solid #ccc; text-align:left; }
table th { background:#141e30; color:#fff; }
.actions a { margin-right:10px; text-decoration:none; color:#fff; padding:6px 12px; border-radius:4px; }
.actions a.edit { background:#00cc7a; }
.actions a.delete { background:#ff4d4d; }
.actions a.edit:hover { background:#00995c; }
.actions a.delete:hover { background:#e60000; }
form input[type="text"] { padding:6px; margin-right:5px; }
form input[type="submit"], .add-btn { background:#00cc7a; color:#fff; border:none; border-radius:4px; cursor:pointer; padding:6px 12px; text-decoration:none; }
form input[type="submit"]:hover, .add-btn:hover { background:#00995c; }
.pagination a { margin:0 5px; text-decoration:none; padding:6px 12px; background:#141e30; color:#fff; border-radius:4px; }
.pagination a.active { background:#00cc7a; }
.logout-btn { display:inline-block; margin-top:10px; padding:10px 20px; background:#ff4d4d; color:#fff; border:none; border-radius:6px; cursor:pointer; text-decoration:none; }
.logout-btn:hover { background:#e60000; }
.cover-img { width:60px; height:60px; object-fit:cover; border-radius:6px; }
</style>
</head>
<body>

<header>
<h1>🎵 Manage Songs</h1>
<p>Welcome, <b><?= htmlspecialchars($username) ?></b></p>
<a href="../logout_admin.php" class="logout-btn">Logout</a>
</header>

<div class="container">
<nav>
<a href="../index.php">🏠 Dashboard</a>
<a href="../manage_songs/songs.php">🎵 Songs</a>
<a href="../manage_artists/artists.php">🎤 Artists</a>
<a href="../manage_genres/genres.php">🎶 Genres</a>
<a href="../manage_categories/categories.php">📁 Categories</a>
<a href="../manage_users/users.php">👥 Users</a>
</nav>

<main>
<div class="card">
<h2>All Songs</h2>
<div style="margin-bottom:10px;">
<a href="add_song.php" class="add-btn">➕ Add New Song</a>
</div>
<br><br>

<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
    <form method="GET" action="" style="margin:0;">
        <input type="text" name="search" placeholder="Search by name" value="<?= htmlspecialchars($search) ?>">
        <input type="submit" value="Search">
    </form>

    <?php if($search == ''): ?>
    <div class="pagination" style="margin:0;">
        <?php for($i=1; $i<=$total_pages; $i++): ?>
        <a href="?page=<?= $i ?>" class="<?= ($i==$page)?'active':'' ?>"><?= $i ?></a>
        <?php endfor; ?>
    </div>
    <?php endif; ?>
</div>

<table>
<tr>
<th>ID</th>
<th>Title</th>
<th>Artist</th>
<th>Category</th>
<th>Genre</th>
<th>Album</th>
<th>Duration</th>
<th>File</th>
<th>Cover</th>
<th>Actions</th>
</tr>

<?php foreach($songs as $row): ?>
<tr>
<td><?= $row['id'] ?></td>
<td><?= htmlspecialchars($row['title']) ?></td>
<td><?= htmlspecialchars($row['artist_name']) ?></td>
<td><?= htmlspecialchars($row['category_name'] ?? '-') ?></td>
<td><?= htmlspecialchars($row['genre_name'] ?? '-') ?></td>
<td><?= htmlspecialchars($row['album']) ?></td>
<td><?= htmlspecialchars($row['duration']) ?></td>
<td><a href="../uploads/songs/<?= htmlspecialchars($row['file_path']) ?>" target="_blank">Play</a></td>
<td>
<?php if($row['cover_image'] && file_exists("../uploads/songs/".$row['cover_image'])): ?>
<img src="../uploads/songs/<?= htmlspecialchars($row['cover_image']) ?>" class="cover-img">
<?php else: ?>
-
<?php endif; ?>
</td>
<td class="actions">
<a class="edit" href="edit_song.php?id=<?= $row['id'] ?>">Edit</a>
<a class="delete" href="remove_song.php?id=<?= $row['id'] ?>" onclick="return confirm('Are you sure?')">Delete</a>
</td>
</tr>
<?php endforeach; ?>
</table>

</div>
</main>
</div>
</body>
</html>

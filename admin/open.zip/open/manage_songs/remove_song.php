<?php
session_name("ADMIN_SESSION");
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: ../admin_login.php");
    exit;
}

require '../db.php';

// Check if ID is provided
if (!isset($_GET['id'])) {
    header("Location: songs.php");
    exit;
}

$id = (int)$_GET['id'];

// Fetch song to get file paths
$stmt = $pdo->prepare("SELECT file_path, cover_image FROM songs WHERE id = ?");
$stmt->execute([$id]);
$song = $stmt->fetch(PDO::FETCH_ASSOC);

if ($song) {
    // Delete audio file
    $audioPath = "../uploads/songs/" . $song['file_path'];
    if (file_exists($audioPath)) unlink($audioPath);

    // Delete cover image if exists
    if ($song['cover_image']) {
        $coverPath = "../uploads/songs/" . $song['cover_image'];
        if (file_exists($coverPath)) unlink($coverPath);
    }

    // Delete record from DB
    $stmt = $pdo->prepare("DELETE FROM songs WHERE id = ?");
    $stmt->execute([$id]);
}

// Redirect back to songs list
header("Location: songs.php");
exit;
?>
